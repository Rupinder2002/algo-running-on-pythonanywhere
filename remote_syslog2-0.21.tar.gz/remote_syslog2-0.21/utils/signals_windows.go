package utils

func AddSignalHandlers() {
	// NOOP
}
